In the config.txt file the first line is your IP address. 
You should change this if you plan on using your external IP.

If you plan to use this externally, make sure you go to 
your router and open the port number 43913.