# CS-370--Labyrinth


### Jonny, 8/28
I created a Java workspace and added the Lightweight Java Game Library (LWJGL). I took the code from the "Getting Started" page on lwjgl.org/guide as a starting template for making the game. This gives us a simple window. I also created some sample sprites for the main tiles in the game.

### Jonny, 9/3
Added the code to display the full 7x7 board. No movement functionality such as rotation or sliding. The board will be randomized each time, except for the stationary tiles. Since there is no rotation, some of the stationary tiles are oriented wrong.
